<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wedding Planner</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
    <header class="header">
        <h1 class="main-title">Welcome to Wedding Bliss</h1>
        <p class="tagline">Your perfect wedding starts here. Plan, organize, and celebrate your special day effortlessly.</p>
    </header>
    
    <div class="content-wrapper">
        <div class="container">
            <h2 class="section-title">Join Our Wedding Community</h2>
            <p class="description">Create or Login an account to access exclusive wedding planning tools.</p>
            
            <div class="form-box" id="login-box">
                <h2>Login</h2>
                <form action="auth.php" method="POST">
                    <input type="hidden" name="action" value="login">
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit">Login</button>
                </form>
                
            </div>

            <div class="form-box hidden" id="register-box">
                <h2>Register</h2>
                <form action="auth.php" method="POST">
                    <input type="hidden" name="action" value="register">
                    <input type="text" name="full_name" placeholder="Full Name" required>
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit">Register</button>
                </form>
                
            </div>
        </div>
    </div>

    
    <script>
        function showRegister() {
            document.getElementById('login-box').classList.add('hidden');
            document.getElementById('register-box').classList.remove('hidden');
        }

        function showLogin() {
            document.getElementById('register-box').classList.add('hidden');
            document.getElementById('login-box').classList.remove('hidden');
        }

        function handleLogin(event) {
            event.preventDefault();
            window.location.href = 'index.html';
        }

        function handleRegister(event) {
            event.preventDefault();
            window.location.href = 'index.html';
        }
    </script>
</body>
</html>

<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection details
$servername = "localhost";
$username = "root"; // Change if you have a different username
$password = ""; // Change if you have a MySQL password
$dbname = "wedding_planner";

// Create database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize form data
    $name = $conn->real_escape_string(trim($_POST['name']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $phone = preg_replace('/[^0-9]/', '', $_POST['phone']); // Remove non-numeric characters
    $wedding_date = $_POST['wedding_date'];

    // Check if any field is empty
    if (empty($name) || empty($email) || empty($phone) || empty($wedding_date)) {
        die("All fields are required.");
    }

    // Insert data into the database
    $stmt = $conn->prepare("INSERT INTO users (name, email, phone, wedding_date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $phone, $wedding_date);

    // Execute query and check if successful
    if ($stmt->execute()) {
        // Redirect to confirmation page
        header("Location: confirmation.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
}
$conn->close();
?>

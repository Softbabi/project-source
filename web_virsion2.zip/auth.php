<?php
session_start();

// Database Connection
$host = "localhost"; // Change if needed
$user = "root"; // Change to your DB username
$password = ""; // Change to your DB password
$database = "main_db"; // Your database name

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handling User Actions (Login/Register)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];

    if ($action == "register") {
        // User Registration
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password

        // Check if email already exists
        $checkQuery = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "User already exists. Please log in.";
        } else {
            // Insert new user
            $insertQuery = "INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($insertQuery);
            $stmt->bind_param("sss", $full_name, $email, $password);

            if ($stmt->execute()) {
                echo "Registration successful! Redirecting to login...";
                header("refresh:2;url=index.html"); // Redirect to index.html after 2 seconds
                exit();
            } else {
                echo "Error: " . $stmt->error;
            }
        }
    } elseif ($action == "login") {
        // User Login
        $email = $_POST['email'];
        $password = $_POST['password'];

        $query = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['full_name'];
                echo "Login successful! Redirecting...";
                header("refresh:2;url=index.html"); // Redirect to homepage after 2 seconds
                exit();
            } else {
                echo "Invalid password.";
            }
        } else {
            echo "User not found.";
        }
    }
}
?>


<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="admin_dash.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <h2>Admin Panel</h2>
            <ul>
                <li><a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="#"><i class="fas fa-users"></i> Manage Users</a></li>
                <li><a href="#"><i class="fas fa-cogs"></i> Settings</a></li>
                <li><a href="#"><i class="fas fa-file-alt"></i> Reports</a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="topbar">
                <h1>Welcome, Admin</h1>
                <a href="logout.php" class="logout-btn">Logout</a>
            </header>

            <section class="dashboard-stats">
                <div class="card">
                    <i class="fas fa-users"></i>
                    <h3>Users</h3>
                    <p>150</p>
                </div>

                <div class="card">
                    <i class="fas fa-calendar-check"></i>
                    <h3>Bookings</h3>
                    <p>75</p>
                </div>

                <div class="card">
                    <i class="fas fa-envelope"></i>
                    <h3>Messages</h3>
                    <p>25</p>
                </div>

                <div class="card">
                    <i class="fas fa-cogs"></i>
                    <h3>Settings</h3>
                    <p>Updated</p>
                </div>
            </section>
        </main>
    </div>
</body>
</html>

// JavaScript for hover effect on service boxes
document.querySelectorAll('.services-col').forEach(box => {
    box.addEventListener('mouseenter', () => {
        box.style.transform = "scale(1.05)"; // Slight scaling effect
        box.style.transition = "transform 0.3s ease";
    });

    box.addEventListener('mouseleave', () => {
        box.style.transform = "scale(1)"; // Reset scale on mouse leave
    });
});

// JavaScript for form validation (if form exists)
const contactForm = document.querySelector("#contactForm");

if (contactForm) {
    contactForm.addEventListener("submit", function(event) {
        const name = document.querySelector("#name").value.trim();
        const email = document.querySelector("#email").value.trim();
        const message = document.querySelector("#message").value.trim();
        let valid = true;
        let errorMsg = "";

        // Validate Name
        if (name === "") {
            errorMsg += "Name is required!\n";
            valid = false;
        }

        // Validate Email (basic check)
        if (email === "" || !email.includes('@') || !email.includes('.')) {
            errorMsg += "Please enter a valid email!\n";
            valid = false;
        }

        // Validate Message
        if (message === "") {
            errorMsg += "Message is required!\n";
            valid = false;
        }

        if (!valid) {
            alert(errorMsg); // Show all errors at once
            event.preventDefault(); // Prevent form submission
        }
    });
}

// Example of toggle behavior for a "read more" button
const readMoreButton = document.querySelector('#readMore');
const extraInfo = document.querySelector('#extraInfo');

if (readMoreButton && extraInfo) {
    readMoreButton.addEventListener('click', () => {
        extraInfo.classList.toggle('hidden'); // Toggle visibility of extra content

        readMoreButton.textContent = extraInfo.classList.contains('hidden')
            ? "Read More"
            : "Read Less";
    });
}

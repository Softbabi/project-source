#include<iostream>
using namespace std;
cout<<"vaibhav chavhan"<<endl;
package login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.EtchedBorder;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.SystemColor;

public class Chek_Appointment extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Chek_Appointment frame = new Chek_Appointment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Chek_Appointment() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1122, 658);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 205));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(25, 25, 112), new Color(95, 158, 160)));
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(10, 109, 154, 502);
		contentPane.add(panel);
		
		JButton btnNewButton_2 = new JButton("Home");
		btnNewButton_2.setForeground(new Color(128, 0, 0));
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_2.setBounds(10, 10, 134, 90);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Prescription");
		btnNewButton_3.setForeground(new Color(128, 0, 0));
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 19));
		btnNewButton_3.setBounds(10, 110, 134, 90);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Patient");
		btnNewButton_4.setForeground(new Color(128, 0, 0));
		btnNewButton_4.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_4.setBounds(10, 207, 134, 90);
		panel.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Appoitment");
		btnNewButton_5.setForeground(new Color(128, 0, 0));
		btnNewButton_5.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_5.setBounds(10, 307, 134, 90);
		panel.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("System");
		btnNewButton_6.setForeground(new Color(128, 0, 0));
		btnNewButton_6.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_6.setBounds(10, 407, 134, 90);
		panel.add(btnNewButton_6);
		
		JButton btnNewButton_1 = new JButton("Logout");
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnNewButton_1.setBounds(924, 10, 174, 60);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Exit\r\n");
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnNewButton.setBounds(977, 80, 121, 45);
		contentPane.add(btnNewButton);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(184, 10, 730, 104);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Check Appointment");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 34));
		lblNewLabel.setBounds(204, 23, 308, 51);
		panel_1.add(lblNewLabel);
	}
}

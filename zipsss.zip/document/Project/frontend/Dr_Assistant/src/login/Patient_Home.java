package login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.CardLayout;
import javax.swing.border.MatteBorder;

import com.mysql.cj.xdevapi.PreparableStatement;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Component;
import java.awt.Toolkit;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Patient_Home extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	Connection con;
	private JTextField t8;
	private JTextField t7;
	private JTextField t6;
	private JTextField t5;
	private JTextField t4;
	private JTextField t3;
	private JTextField t2;
	private JTextField t1;
	String name;
	PreparedStatement ps;
	String n;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Patient_Home frame = new Patient_Home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Patient_Home() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","chetan123");
		} catch (Exception e1) {
			JOptionPane.showMessageDialog(null,e1);
		}
		setTitle("Patient Home");
		setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\clgJava\\Dr_Assistance\\src\\Image\\dr_logo.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1119, 677);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 165, 0));
		panel.setForeground(new Color(64, 0, 64));
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBounds(10, 10, 1098, 132);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("Welcome");
		lblNewLabel.setForeground(new Color(128, 128, 128));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 60));
		lblNewLabel.setBounds(186, 22, 665, 72);
		panel.add(lblNewLabel);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 140, 0));
		panel_1.setBounds(10, 152, 204, 492);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JButton btnNewButton_2 = new JButton("\r\nAppointment");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Appointment obj=new Appointment();
				obj.setVisible(true);
				dispose();	
			}
		});
		btnNewButton_2.setForeground(new Color(0, 100, 0));
		btnNewButton_2.setFont(new Font("Tw Cen MT", Font.BOLD, 27));
		btnNewButton_2.setBounds(10, 35, 184, 105);
		panel_1.add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("FeedBack");
		btnNewButton_3.setForeground(new Color(0, 100, 0));
		btnNewButton_3.setFont(new Font("Tw Cen MT", Font.BOLD, 34));
		btnNewButton_3.setBounds(10, 341, 184, 105);
		panel_1.add(btnNewButton_3);

		JButton btnNewButton_4 = new JButton("ABOUT");
		btnNewButton_4.setForeground(new Color(0, 100, 0));
		btnNewButton_4.setFont(new Font("Tw Cen MT", Font.BOLD, 40));
		btnNewButton_4.setBounds(10, 187, 184, 116);
		panel_1.add(btnNewButton_4);

		JPanel panel_2 = new JPanel();
		panel_2.setBorder(null);
		panel_2.setAlignmentX(Component.RIGHT_ALIGNMENT);
		panel_2.setBackground(new Color(255, 160, 122));
		panel_2.setBounds(214, 152, 894, 492);
		contentPane.add(panel_2);
		panel_2.setLayout(null);

		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Dr_Assistant obj=new Dr_Assistant();
				obj.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_1.setIcon(new ImageIcon("D:\\clgJava\\Project\\Dr_Assistant\\src\\Image\\back.png"));
		btnNewButton_1.setBounds(755, 10, 129, 49);
		panel_2.add(btnNewButton_1);

		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.BOLD, 30));
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				try {
					PreparedStatement pst=con.prepareStatement("select * from patient where pID=?");
					pst.setString(1, textField.getText());
					ResultSet rs=pst.executeQuery();
										
					if(rs.next()) {
						n=rs.getString(2);
						t1.setText(rs.getString(2));
						t2.setText(rs.getString(3));
						t3.setText(rs.getString(4));
						t4.setText(rs.getString(5));
						t7.setText(rs.getString(6));
						t6.setText(rs.getString(7));
					}
					else
					{
						t1.setText("......................................................");
						t2.setText("......................................................");
						t3.setText("......................................................");
						t4.setText("......................................................");
						t7.setText("......................................................");
						t6.setText("......................................................");	
					}
					
					PreparedStatement ps=con.prepareStatement("select * from App where pName=?");
					pst.setString(1,n);
					ResultSet r=ps.executeQuery();
					if(r.next())
					{
						t5.setText(r.getString(3));
						t5.setText(r.getString(5));
					}
					else {
						t5.setText("");
						t5.setText("");
					}
				}
				catch(Exception ex)
				{
					//JOptionPane.showMessageDialog(null,ex);
				}
			}
		});
		textField.setBounds(180, 10, 60, 49);
		panel_2.add(textField);
		textField.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Enter ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblNewLabel_1.setBounds(22, 19, 148, 35);
		panel_2.add(lblNewLabel_1);

		JSeparator separator = new JSeparator();
		separator.setBounds(0, 62, 884, 2);
		panel_2.add(separator);

		JLabel lblNewLabel_2 = new JLabel("Patient History");
		lblNewLabel_2.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_2.setForeground(new Color(128, 0, 0));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_2.setBounds(322, 11, 359, 35);
		panel_2.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Name :");
		lblNewLabel_3.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_3.setBounds(32, 88, 112, 26);
		panel_2.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("Contact :");
		lblNewLabel_4.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_4.setBounds(32, 138, 112, 29);
		panel_2.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("Address :");
		lblNewLabel_5.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_5.setBounds(32, 189, 112, 29);
		panel_2.add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("Allergies :");
		lblNewLabel_6.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_6.setBounds(32, 248, 112, 29);
		panel_2.add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("Date :");
		lblNewLabel_7.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_7.setBounds(32, 298, 112, 26);
		panel_2.add(lblNewLabel_7);

		JLabel lblNewLabel_8 = new JLabel("DOB :");
		lblNewLabel_8.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_8.setBounds(405, 84, 106, 35);
		panel_2.add(lblNewLabel_8);

		JLabel lblNewLabel_9 = new JLabel("Gender :");
		lblNewLabel_9.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_9.setBounds(405, 138, 106, 29);
		panel_2.add(lblNewLabel_9);

		JLabel lblNewLabel_10 = new JLabel("Doc Name :");
		lblNewLabel_10.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_10.setBounds(405, 190, 153, 26);
		panel_2.add(lblNewLabel_10);

		t8 = new JTextField();
		t8.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t8.setBorder(null);
		t8.setSelectionColor(new Color(255, 160, 122));
		t8.setDisabledTextColor(new Color(255, 160, 122));
		t8.setForeground(new Color(0, 0, 0));
		t8.setBackground(new Color(255, 160, 122));
		t8.setText("......................................................");
		t8.setBounds(548, 189, 235, 30);
		panel_2.add(t8);
		t8.setColumns(10);

		t7 = new JTextField();
		t7.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t7.setBorder(null);
		t7.setSelectionColor(new Color(255, 160, 122));
		t7.setDisabledTextColor(new Color(255, 160, 122));
		t7.setForeground(new Color(0, 0, 0));
		t7.setText("......................................................");
		t7.setColumns(10);
		t7.setBackground(new Color(255, 160, 122));
		t7.setBounds(528, 139, 235, 30);
		panel_2.add(t7);

		t6 = new JTextField();
		t6.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t6.setBorder(null);
		t6.setSelectionColor(new Color(255, 160, 122));
		t6.setDisabledTextColor(new Color(255, 160, 122));
		t6.setForeground(new Color(0, 0, 0));
		t6.setText("......................................................");
		t6.setColumns(10);
		t6.setBackground(new Color(255, 160, 122));
		t6.setBounds(518, 98, 235, 30);
		panel_2.add(t6);

		t5 = new JTextField();
		t5.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t5.setBorder(null);
		t5.setSelectionColor(new Color(255, 160, 122));
		t5.setDisabledTextColor(new Color(255, 160, 122));
		t5.setForeground(new Color(0, 0, 0));
		t5.setText("......................................................");
		t5.setColumns(10);
		t5.setBackground(new Color(255, 160, 122));
		t5.setBounds(141, 306, 235, 30);
		panel_2.add(t5);

		t4 = new JTextField();
		t4.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t4.setBorder(null);
		t4.setSelectionColor(new Color(255, 160, 122));
		t4.setDisabledTextColor(new Color(255, 160, 122));
		t4.setForeground(new Color(0, 0, 0));
		t4.setText("......................................................");
		t4.setColumns(10);
		t4.setBackground(new Color(255, 160, 122));
		t4.setBounds(154, 259, 235, 30);
		panel_2.add(t4);

		t3 = new JTextField();
		t3.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t3.setBorder(null);
		t3.setSelectionColor(new Color(255, 160, 122));
		t3.setDisabledTextColor(new Color(255, 160, 122));
		t3.setForeground(new Color(0, 0, 0));
		t3.setText("......................................................");
		t3.setColumns(10);
		t3.setBackground(new Color(255, 160, 122));
		t3.setBounds(141, 200, 235, 30);
		panel_2.add(t3);

		t2 = new JTextField();
		t2.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t2.setBorder(null);
		t2.setSelectionColor(new Color(255, 160, 122));
		t2.setDisabledTextColor(new Color(255, 160, 122));
		t2.setForeground(new Color(0, 0, 0));
		t2.setText("......................................................");
		t2.setColumns(10);
		t2.setBackground(new Color(255, 160, 122));
		t2.setBounds(141, 149, 235, 30);
		panel_2.add(t2);

		t1 = new JTextField();
		t1.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t1.setBorder(null);
		t1.setSelectionColor(new Color(255, 160, 122));
		t1.setDisabledTextColor(new Color(255, 160, 122));
		t1.setForeground(new Color(0, 0, 0));
		t1.setText("......................................................");
		t1.setColumns(10);
		t1.setBackground(new Color(255, 160, 122));
		t1.setBounds(141, 98, 235, 30);
		panel_2.add(t1);
	}
	public void name(String name)
	{
		name=name;
	}
}

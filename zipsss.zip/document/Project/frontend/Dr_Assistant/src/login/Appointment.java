package login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.border.MatteBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Appointment extends JFrame {

	private JPanel contentPane;
	private JTextField t4;
	private JTextField t7;
	private JTextField t6;
	private JTextField t5;
	private JTextField t8;
	private JTextField t3;
	private JTextField t2;
	private JTextField t1;
	private JTextField t9;
	int n;
	Connection con;
	PreparedStatement pst;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Appointment frame = new Appointment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Appointment() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","chetan123");
		} catch (Exception e1) {
			JOptionPane.showMessageDialog(null,e1);
		}
		setTitle("Appointment");
		setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\clgJava\\Dr_Assistance\\src\\Image\\dr_logo.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1119, 677);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setForeground(new Color(64, 0, 64));
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(new Color(255, 165, 0));
		panel.setBounds(0, 0, 1098, 132);
		contentPane.add(panel);

		JLabel lblBookAppointment = new JLabel("Book Appointment");
		lblBookAppointment.setForeground(new Color(105, 105, 105));
		lblBookAppointment.setHorizontalAlignment(SwingConstants.CENTER);
		lblBookAppointment.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 60));
		lblBookAppointment.setBounds(289, 22, 534, 72);
		panel.add(lblBookAppointment);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\rsz_update_details.png"));
		lblNewLabel.setBounds(220, 40, 59, 54);
		panel.add(lblNewLabel);

		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(255, 140, 0));
		panel_1.setBounds(0, 142, 204, 492);
		contentPane.add(panel_1);

		JButton btnNewButton_2 = new JButton("Home");
		btnNewButton_2.setForeground(new Color(0, 128, 0));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient_Home obj=new Patient_Home();
				obj.setVisible(true);
				dispose();				
			}
		});
		btnNewButton_2.setFont(new Font("Tw Cen MT", Font.BOLD, 40));
		btnNewButton_2.setBounds(10, 35, 184, 105);
		panel_1.add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("FeedBack");
		btnNewButton_3.setForeground(new Color(0, 128, 0));
		btnNewButton_3.setFont(new Font("Tw Cen MT", Font.BOLD, 34));
		btnNewButton_3.setBounds(10, 341, 184, 105);
		panel_1.add(btnNewButton_3);

		JButton btnNewButton_4 = new JButton("ABOUT");
		btnNewButton_4.setForeground(new Color(0, 128, 0));
		btnNewButton_4.setFont(new Font("Tw Cen MT", Font.BOLD, 40));
		btnNewButton_4.setBounds(10, 187, 184, 116);
		panel_1.add(btnNewButton_4);

		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBorder(null);
		panel_2.setBackground(new Color(255, 160, 122));
		panel_2.setAlignmentX(1.0f);
		panel_2.setBounds(204, 142, 894, 492);
		contentPane.add(panel_2);

		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Dr_Assistant obj=new Dr_Assistant();
				obj.setVisible(true);
				dispose();	
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\back.png"));
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_1.setBounds(737, 9, 147, 49);
		panel_2.add(btnNewButton_1);

		JSeparator separator = new JSeparator();
		separator.setBounds(0, 62, 884, 2);
		panel_2.add(separator);

		JLabel lblNewLabel_2 = new JLabel("Appointment");
		lblNewLabel_2.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_2.setForeground(new Color(128, 0, 0));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_2.setBounds(322, 11, 359, 35);
		panel_2.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Name :");
		lblNewLabel_3.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_3.setBounds(32, 88, 112, 26);
		panel_2.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("Date :");
		lblNewLabel_4.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_4.setBounds(32, 138, 112, 29);
		panel_2.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("Time :");
		lblNewLabel_5.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_5.setBounds(32, 189, 112, 29);
		panel_2.add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("Treatment For :");
		lblNewLabel_6.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6.setBounds(427, 88, 164, 29);
		panel_2.add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("Allergies :");
		lblNewLabel_7.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_7.setBounds(32, 298, 112, 26);
		panel_2.add(lblNewLabel_7);

		JLabel lblNewLabel_8 = new JLabel("Age :");
		lblNewLabel_8.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_8.setBounds(32, 337, 106, 35);
		panel_2.add(lblNewLabel_8);

		JLabel lblNewLabel_9 = new JLabel("Gender :");
		lblNewLabel_9.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_9.setBounds(32, 395, 106, 29);
		panel_2.add(lblNewLabel_9);

		JLabel lblNewLabel_10 = new JLabel("Doc Name :");
		lblNewLabel_10.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_10.setBounds(32, 250, 129, 26);
		panel_2.add(lblNewLabel_10);

		t4 = new JTextField();
		t4.setSelectionColor(new Color(255, 160, 122));
		t4.setForeground(Color.BLACK);
		t4.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t4.setDisabledTextColor(new Color(255, 160, 122));
		t4.setColumns(10);
		t4.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		t4.setBackground(new Color(250, 240, 230));
		t4.setBounds(148, 248, 235, 30);
		panel_2.add(t4);

		t7 = new JTextField();
		t7.setSelectionColor(new Color(255, 160, 122));
		t7.setForeground(Color.BLACK);
		t7.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t7.setDisabledTextColor(new Color(255, 160, 122));
		t7.setColumns(10);
		t7.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		t7.setBackground(new Color(250, 240, 230));
		t7.setBounds(148, 396, 235, 30);
		panel_2.add(t7);

		t6 = new JTextField();
		t6.setSelectionColor(new Color(255, 160, 122));
		t6.setForeground(Color.BLACK);
		t6.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t6.setDisabledTextColor(new Color(255, 160, 122));
		t6.setColumns(10);
		t6.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		t6.setBackground(new Color(250, 240, 230));
		t6.setBounds(148, 344, 235, 30);
		panel_2.add(t6);

		t5 = new JTextField();
		t5.setSelectionColor(new Color(255, 160, 122));
		t5.setForeground(Color.BLACK);
		t5.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t5.setDisabledTextColor(new Color(255, 160, 122));
		t5.setColumns(10);
		t5.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		t5.setBackground(new Color(250, 240, 230));
		t5.setBounds(148, 296, 235, 30);
		panel_2.add(t5);

		t8 = new JTextField();
		t8.setSelectionColor(new Color(255, 160, 122));
		t8.setForeground(Color.BLACK);
		t8.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t8.setDisabledTextColor(new Color(255, 160, 122));
		t8.setColumns(10);
		t8.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		t8.setBackground(new Color(250, 240, 230));
		t8.setBounds(590, 86, 235, 30);
		panel_2.add(t8);

		t3 = new JTextField();
		t3.setSelectionColor(new Color(255, 160, 122));
		t3.setForeground(Color.BLACK);
		t3.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t3.setDisabledTextColor(new Color(255, 160, 122));
		t3.setColumns(10);
		t3.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		t3.setBackground(new Color(250, 240, 230));
		t3.setBounds(141, 190, 235, 30);
		panel_2.add(t3);
			
		t2 = new JTextField();
		t2.setSelectionColor(new Color(255, 160, 122));
		t2.setForeground(Color.BLACK);
		t2.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t2.setDisabledTextColor(new Color(255, 160, 122));
		t2.setColumns(10);
		t2.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		t2.setBackground(new Color(250, 240, 230));
		t2.setBounds(141, 139, 235, 30);
		panel_2.add(t2);

		t1 = new JTextField();
		t1.setSelectionColor(new Color(255, 160, 122));
		t1.setForeground(Color.BLACK);
		t1.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t1.setDisabledTextColor(new Color(255, 160, 122));
		t1.setColumns(10);
		t1.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		t1.setBackground(new Color(250, 240, 230));
		t1.setBounds(141, 86, 235, 30);
		panel_2.add(t1);

		t9 = new JTextField();
		t9.setEditable(false);
		t9.setSelectionColor(new Color(255, 160, 122));
		t9.setForeground(Color.BLACK);
		t9.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t9.setDisabledTextColor(new Color(255, 160, 122));
		t9.setColumns(10);
		t9.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		t9.setBackground(new Color(250, 240, 230));
		t9.setBounds(517, 138, 112, 30);
		panel_2.add(t9);

		JLabel lblNewLabel_4_1 = new JLabel("Fees :");
		lblNewLabel_4_1.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_4_1.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_4_1.setBounds(427, 138, 80, 29);
		panel_2.add(lblNewLabel_4_1);

		JButton btnNewButton = new JButton("Book Appointment");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(n>0)
				{
					try {
						pst=con.prepareStatement("Insert into App values(aID,?,?,?,?,?,?,?,?,?)");
						pst.setString(1,t1.getText());
						pst.setString(2,t2.getText());
						pst.setString(3,t3.getText());
						pst.setString(4,t4.getText());
						pst.setString(5,t5.getText());
						pst.setInt(6,Integer.parseInt(t6.getText()));
						pst.setString(7,t7.getText());
						pst.setString(8,t8.getText());
						pst.setInt(9,Integer.parseInt(t9.getText()));
						pst.executeUpdate();
						pst.clearParameters();
						JOptionPane.showMessageDialog(null,"Book Apointment Succesfully","Status",JOptionPane.INFORMATION_MESSAGE);	
						t1.setText("");
						t2.setText("");
						t3.setText("");
						t4.setText("");
						t5.setText("");
						t6.setText("");
						t7.setText("");
						t8.setText("");
					

					} catch (Exception e1) {
						JOptionPane.showMessageDialog(null,e1,"Status",JOptionPane.INFORMATION_MESSAGE);
					}
				}
				else {
					JOptionPane.showMessageDialog(null,"Payment First","Payment Detail",JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		btnNewButton.setForeground(new Color(128, 0, 0));
		btnNewButton.setBorder(null);
		btnNewButton.setBackground(new Color(50, 205, 50));
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 18));
		btnNewButton.setBounds(517, 199, 223, 61);
		panel_2.add(btnNewButton);

		JButton btnNewButton_5 = new JButton("Pay");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				t9.setText("200");
				n++;
			}
		});
		btnNewButton_5.setForeground(new Color(128, 0, 0));
		btnNewButton_5.setBorder(null);
		btnNewButton_5.setBackground(new Color(100, 149, 237));
		btnNewButton_5.setFont(new Font("Verdana", Font.BOLD, 19));
		btnNewButton_5.setBounds(655, 138, 80, 29);
		panel_2.add(btnNewButton_5);
	}
}

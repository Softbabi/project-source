package login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.border.EtchedBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.MatteBorder;
import javax.swing.SwingConstants;

public class Home extends JFrame {

	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home frame = new Home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Home() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 1037, 640);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 230, 140));
		contentPane.setForeground(new Color(240, 230, 140));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Exit\r\n");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a=JOptionPane.showConfirmDialog(null,"Do you Want to close the application","select",JOptionPane.YES_NO_OPTION);
				   if (a==0)
				   {
				      dispose();
				   }
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnNewButton.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\Close.png"));
		btnNewButton.setBounds(892, 70, 121, 45);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Logout");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				Login obj=new Login();
				obj.setVisible(true);
				dispose();
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(null,ex,"Status",JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnNewButton_1.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\exit.png"));
		btnNewButton_1.setBounds(839, 0, 174, 60);
		contentPane.add(btnNewButton_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(25, 25, 112), new Color(95, 158, 160)));
		panel_1.setBounds(164, 0, 673, 86);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("DR ASSISTANT");
		lblNewLabel.setBounds(127, 7, 419, 70);
		panel_1.add(lblNewLabel);
		lblNewLabel.setForeground(new Color(128, 0, 0));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 60));
		lblNewLabel.setLabelFor(contentPane);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\icon\\890961816.png"));
		lblNewLabel_6.setBounds(0, 0, 673, 86);
		panel_1.add(lblNewLabel_6);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome Home");
		lblNewLabel_1.setForeground(new Color(139, 69, 19));
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 40));
		lblNewLabel_1.setBounds(377, 96, 280, 45);
		contentPane.add(lblNewLabel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new CompoundBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(192, 192, 192)), null));
		panel_2.setBackground(new Color(250, 250, 210));
		panel_2.setBounds(179, 152, 174, 167);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Total Patient");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(new Color(255, 0, 0));
		lblNewLabel_2.setBackground(new Color(0, 255, 0));
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 21));
		lblNewLabel_2.setBounds(10, 10, 154, 28);
		panel_2.add(lblNewLabel_2);
		
		JButton btnNewButton_7 = new JButton("Add New Patient");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient_registration obj=new Patient_registration();
				obj.setVisible(true);
				
			}
		});
		btnNewButton_7.setBackground(new Color(255, 165, 0));
		btnNewButton_7.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_7.setBounds(10, 129, 154, 28);
		panel_2.add(btnNewButton_7);
		
		JLabel lblNewLabel_7 = new JLabel("999");
		lblNewLabel_7.setForeground(new Color(85, 107, 47));
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 55));
		lblNewLabel_7.setBounds(30, 37, 114, 78);
		panel_2.add(lblNewLabel_7);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new CompoundBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(192, 192, 192)), null));
		panel_3.setBackground(new Color(250, 250, 210));
		panel_3.setBounds(377, 152, 174, 167);
		contentPane.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("Appointments");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setForeground(new Color(255, 0, 0));
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblNewLabel_3.setBounds(10, 10, 154, 26);
		panel_3.add(lblNewLabel_3);
		
		JButton btnNewButton_8 = new JButton("New Appointment");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Appointment obj=new Appointment();
				obj.setVisible(true);
				dispose();
			}
		});
		btnNewButton_8.setBackground(new Color(255, 165, 0));
		btnNewButton_8.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_8.setBounds(10, 131, 154, 26);
		panel_3.add(btnNewButton_8);
		
		JLabel lblNewLabel_7_1 = new JLabel("999");
		lblNewLabel_7_1.setForeground(new Color(85, 107, 47));
		lblNewLabel_7_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7_1.setFont(new Font("Tahoma", Font.PLAIN, 55));
		lblNewLabel_7_1.setBounds(31, 43, 114, 78);
		panel_3.add(lblNewLabel_7_1);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new CompoundBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(192, 192, 192)), null));
		panel_4.setBackground(new Color(250, 250, 210));
		panel_4.setBounds(572, 152, 174, 167);
		contentPane.add(panel_4);
		panel_4.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("Total Prescription");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setForeground(new Color(255, 0, 0));
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_4.setBounds(10, 10, 154, 29);
		panel_4.add(lblNewLabel_4);
		
		JButton btnNewButton_9 = new JButton("Write Prescription");
		btnNewButton_9.setBackground(new Color(255, 165, 0));
		btnNewButton_9.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_9.setBounds(10, 128, 154, 29);
		panel_4.add(btnNewButton_9);
		
		JLabel lblNewLabel_7_2 = new JLabel("999");
		lblNewLabel_7_2.setForeground(new Color(85, 107, 47));
		lblNewLabel_7_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7_2.setFont(new Font("Tahoma", Font.PLAIN, 55));
		lblNewLabel_7_2.setBounds(31, 40, 114, 78);
		panel_4.add(lblNewLabel_7_2);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBorder(new CompoundBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(192, 192, 192)), null));
		panel_5.setBackground(new Color(250, 250, 210));
		panel_5.setBounds(770, 152, 174, 167);
		contentPane.add(panel_5);
		panel_5.setLayout(null);
		
		JLabel lblNewLabel_5 = new JLabel("Patient History");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setForeground(new Color(255, 0, 0));
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblNewLabel_5.setBounds(10, 10, 154, 27);
		panel_5.add(lblNewLabel_5);
		
		JButton btnNewButton_10 = new JButton("Patient History");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient obj=new Patient();
				obj.setVisible(true);;
				dispose();
			}
		});
		btnNewButton_10.setBackground(new Color(255, 165, 0));
		btnNewButton_10.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_10.setBounds(10, 129, 154, 28);
		panel_5.add(btnNewButton_10);
		
		JLabel lblNewLabel_7_3 = new JLabel("999");
		lblNewLabel_7_3.setForeground(new Color(85, 107, 47));
		lblNewLabel_7_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7_3.setFont(new Font("Tahoma", Font.PLAIN, 55));
		lblNewLabel_7_3.setBounds(31, 41, 114, 78);
		panel_5.add(lblNewLabel_7_3);
		
		JLabel lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setForeground(new Color(255, 0, 255));
		lblNewLabel_8.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\BGGG.png"));
		lblNewLabel_8.setBounds(8, 10, 144, 76);
		contentPane.add(lblNewLabel_8);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(25, 25, 112), new Color(95, 158, 160)));
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(8, 91, 154, 502);
		contentPane.add(panel);
		
		JButton btnNewButton_2 = new JButton("Home");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"You Already Home Page","Status",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnNewButton_2.setForeground(new Color(128, 0, 0));
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_2.setBounds(10, 10, 134, 90);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Prescription");
		btnNewButton_3.setForeground(new Color(128, 0, 0));
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 19));
		btnNewButton_3.setBounds(10, 110, 134, 90);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Patient");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient obj=new Patient();
				obj.setVisible(true);;
				dispose();
			}
		});
		btnNewButton_4.setForeground(new Color(128, 0, 0));
		btnNewButton_4.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_4.setBounds(10, 207, 134, 90);
		panel.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Appoitment");
		btnNewButton_5.setForeground(new Color(128, 0, 0));
		btnNewButton_5.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_5.setBounds(10, 307, 134, 90);
		panel.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("System");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System obj=new System();
				obj.setVisible(true);;
				dispose();
			}
		});
		btnNewButton_6.setForeground(new Color(128, 0, 0));
		btnNewButton_6.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_6.setBounds(10, 407, 134, 90);
		panel.add(btnNewButton_6);
	}
	private static void addPopup(Component component, final JPopupMenu popup) {
	}
}

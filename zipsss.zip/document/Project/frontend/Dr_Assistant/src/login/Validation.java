package login;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation {

	public static boolean checkContactNo(String str)
    {
      boolean valid = false;	
    	
  	   
  	   Pattern ptr = Pattern.compile("(0/91)?[7-9][0-9]{9}");
  	   
  	   Matcher match = ptr.matcher(str);
  	   
  	   if(match.find()&&match.group().equals(str))
  	   {
  		 valid = true;
  	   }
  	   
  	   return valid;
    }
    
	public static boolean checkEmail(String str) {
		
    	boolean valid = false;
    	
    	String regex = "^(.+)@(.+)$";  
		Pattern pattern = Pattern.compile(regex);  
		
		Matcher matcher = pattern.matcher(str);  
		 
		 if(matcher.matches()) {
			 valid = true; 
		 }
		 
		return valid;
    }
    
	public static boolean checkNames(String str)
    {
    	 str = str.replaceAll("\\s", "");
        return (str.matches("[a-zA-Z]+"));
    }

	public static boolean checkNumbers(String str)
    {
    	 str = str.replaceAll("\\s", "");
        return (str.matches("[0-9]+"));
    }

	public static boolean checkPassword(String str)
    {
        return (str.matches("[a-zA-Z]+"+"[0-9]+"));
    }

	public  static boolean isValidUsername(String str)
    {
        String regex = "^[A-Za-z]\\w{5,29}$";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(str);
        return m.matches();
    }
  

}
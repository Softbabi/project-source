package login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.CompoundBorder;
import javax.swing.border.MatteBorder;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JSeparator;
import java.awt.Toolkit;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JProgressBar;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Patient extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	DefaultTableModel model;
	Vector v;
	private JTable table;
	private JTextField textField_5;
	private JTextField textField_6;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Patient frame = new Patient();
					frame.setVisible(true);
					frame.initComponant();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void initComponant() {
		try {
			pst=con.prepareStatement("select * from patient");
			rs=pst.executeQuery();
			ResultSetMetaData rsdm=rs.getMetaData();
			model =(DefaultTableModel)table.getModel();
			
		    v=null;
			while(rs.next()) {
				v=new Vector();
				for(int i=1;i<=7;i++) {
					v.add(rs.getInt(1));
					v.add(rs.getString(2));
					v.add(rs.getInt(3));
					v.add(rs.getString(4));
					v.add(rs.getString(5));
					v.add(rs.getString(6));
					v.add(rs.getString(7));
				}
				model.addRow(v);
			}	
			}		
			catch(Exception e1) {
				JOptionPane.showMessageDialog(null, e1);
			}
	}
	public Patient() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","chetan123");
		} catch (Exception e1) {
			JOptionPane.showMessageDialog(null,e1);
		}
		setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\clgJava\\Dr_Assistance\\src\\Image\\add new patient.png"));
		setTitle("Patient");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1083, 654);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 230, 140));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(4, 90, 154, 512);
		contentPane.add(panel);
		panel.setLayout(null);
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(25, 25, 112), new Color(95, 158, 160)));

		JButton btnNewButton_2 = new JButton("Home");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setForeground(new Color(128, 0, 0));
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_2.setBounds(10, 10, 134, 90);
		panel.add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("Prescription");
		btnNewButton_3.setForeground(new Color(128, 0, 0));
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 19));
		btnNewButton_3.setBounds(10, 110, 134, 90);
		panel.add(btnNewButton_3);

		JButton btnNewButton_4 = new JButton("Patient");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"You Already Patient Page","Status",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnNewButton_4.setForeground(new Color(128, 0, 0));
		btnNewButton_4.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_4.setBounds(10, 207, 134, 90);
		panel.add(btnNewButton_4);

		JButton btnNewButton_5 = new JButton("Appoitment");
		btnNewButton_5.setForeground(new Color(128, 0, 0));
		btnNewButton_5.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_5.setBounds(10, 307, 134, 90);
		panel.add(btnNewButton_5);

		JButton btnNewButton_6 = new JButton("System");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System obj=new System();
				obj.setVisible(true);
				dispose();
			}
		});
		btnNewButton_6.setForeground(new Color(128, 0, 0));
		btnNewButton_6.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_6.setBounds(10, 407, 134, 90);
		panel.add(btnNewButton_6);

		JLabel lblNewLabel = new JLabel("DR ASSISTANT");
		lblNewLabel.setForeground(new Color(128, 0, 0));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 60));
		lblNewLabel.setBounds(281, 10, 419, 70);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\icon\\890961816.png"));
		lblNewLabel_6.setBounds(164, 0, 673, 86);
		contentPane.add(lblNewLabel_6);

		JSeparator separator = new JSeparator();
		separator.setForeground(Color.GRAY);
		separator.setBounds(164, 129, 874, 12);
		contentPane.add(separator);

		JLabel lblNewLabel_1 = new JLabel("Patients ID");
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setFont(new Font("Calibri Light", Font.BOLD | Font.ITALIC, 35));
		lblNewLabel_1.setBounds(404, 90, 174, 39);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Name");
		lblNewLabel_2.setForeground(Color.RED);
		lblNewLabel_2.setFont(new Font("Calibri Light", Font.BOLD, 20));
		lblNewLabel_2.setBounds(164, 143, 66, 28);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Phone");
		lblNewLabel_3.setForeground(Color.RED);
		lblNewLabel_3.setFont(new Font("Calibri Light", Font.BOLD, 20));
		lblNewLabel_3.setBounds(164, 235, 66, 28);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("Address");
		lblNewLabel_4.setForeground(Color.RED);
		lblNewLabel_4.setFont(new Font("Calibri Light", Font.BOLD, 20));
		lblNewLabel_4.setBounds(349, 147, 78, 21);
		contentPane.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("DOB");
		lblNewLabel_5.setForeground(Color.RED);
		lblNewLabel_5.setFont(new Font("Calibri Light", Font.BOLD, 20));
		lblNewLabel_5.setBounds(539, 145, 45, 25);
		contentPane.add(lblNewLabel_5);

		JLabel lblNewLabel_7 = new JLabel("Gender");
		lblNewLabel_7.setForeground(Color.RED);
		lblNewLabel_7.setFont(new Font("Calibri Light", Font.BOLD, 20));
		lblNewLabel_7.setBounds(539, 239, 66, 21);
		contentPane.add(lblNewLabel_7);

		JLabel lblNewLabel_8 = new JLabel("Allergies\r\n");
		lblNewLabel_8.setForeground(Color.RED);
		lblNewLabel_8.setFont(new Font("Calibri Light", Font.BOLD, 20));
		lblNewLabel_8.setBounds(714, 144, 96, 27);
		contentPane.add(lblNewLabel_8);

		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.BOLD, 18));
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				try {
					PreparedStatement pst=con.prepareStatement("select * from patient where pName=?");
					pst.setString(1, textField.getText());
					ResultSet rs=pst.executeQuery();
					if(rs.next()) {
						textField_6.setText(rs.getString(1));
						textField_1.setText(rs.getString(3));
						textField_2.setText(rs.getString(5));
						textField_3.setText(rs.getString(4));
						textField_4.setText(rs.getString(7));
						textField_5.setText(rs.getString(6));
					}
					else {
						textField_1.setText("");
						textField_2.setText("");
						textField_3.setText("");
						textField_4.setText("");
						textField_5.setText("");
						textField_6.setText("");
					}
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null,e1);
				}
			}
		});
		textField.setBounds(164, 181, 136, 28);
		contentPane.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		textField_1.setBounds(164, 273, 136, 28);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		textField_2 = new JTextField();
		textField_2.setFont(new Font("Times New Roman", Font.BOLD, 18));
		textField_2.setBounds(526, 180, 121, 29);
		contentPane.add(textField_2);
		textField_2.setColumns(10);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(164, 323, 876, 12);
		contentPane.add(separator_1);

		JButton btnNewButton_8 = new JButton("\r\nUpdate");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					pst=con.prepareStatement("update patient set pName=?,pCon=?,pAdd=?,pDOB=?,pGen=?,pAll=? where pId=?");
					pst.setString(1, textField.getText());
					pst.setString(2, textField_1.getText());
					pst.setString(3, textField_3.getText());
					pst.setString(4, textField_2.getText());
					pst.setString(5, textField_5.getText());
					pst.setString(6, textField_4.getText());
					pst.setString(7, textField_6.getText());
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "Data Updated");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
					textField_4.setText("");
					textField_5.setText("");
					textField_6.setText("");
				} catch (SQLException e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
			}
		});
		btnNewButton_8.setBackground(Color.WHITE);
		btnNewButton_8.setForeground(Color.DARK_GRAY);
		btnNewButton_8.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnNewButton_8.setBounds(919, 171, 121, 39);
		contentPane.add(btnNewButton_8);

		JLabel lblNewLabel_9 = new JLabel("Patient\r\n");
		lblNewLabel_9.setBackground(new Color(176, 196, 222));
		lblNewLabel_9.setForeground(new Color(255, 69, 0));
		lblNewLabel_9.setFont(new Font("Calibri Light", Font.BOLD, 25));
		lblNewLabel_9.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\add new patient.png"));
		lblNewLabel_9.setBounds(10, 10, 144, 70);
		contentPane.add(lblNewLabel_9);

		textField_3 = new JTextField();
		textField_3.setFont(new Font("Times New Roman", Font.BOLD, 18));
		textField_3.setBounds(331, 178, 154, 123);
		contentPane.add(textField_3);
		textField_3.setColumns(10);

		textField_4 = new JTextField();
		textField_4.setFont(new Font("Times New Roman", Font.BOLD, 18));
		textField_4.setBounds(703, 181, 159, 112);
		contentPane.add(textField_4);
		textField_4.setColumns(10);

		JButton btnNewButton_9 = new JButton("Delete");
		btnNewButton_9.setForeground(Color.BLACK);
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					PreparedStatement pst=con.prepareStatement("delete from patient where pID=?");
					pst.setInt(1,Integer.parseInt(textField_6.getText()));
					int a=JOptionPane.showConfirmDialog(null,"Do you Want to close the application","select",JOptionPane.YES_NO_OPTION);
					   if (a==0)
					   {
						   pst.executeUpdate();
							JOptionPane.showMessageDialog(null,"Data Deleted","Status",JOptionPane.INFORMATION_MESSAGE);
							pst.clearParameters();
							textField.setText("");
							textField_1.setText("");
							textField_2.setText("");
							textField_3.setText("");
							textField_4.setText("");
							textField_5.setText("");
							textField_6.setText("");
					   }
					    
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null,e1);
				}
			}
		});
		btnNewButton_9.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnNewButton_9.setBounds(919, 226, 121, 37);
		contentPane.add(btnNewButton_9);

		JButton btnNewButton_10 = new JButton("Add New");
		btnNewButton_10.setIcon(new ImageIcon("E:\\Image\\add new patient.png"));
		btnNewButton_10.setForeground(Color.BLACK);
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient_registration obj=new Patient_registration();
				obj.setVisible(true);
				
			}
		});
		btnNewButton_10.setFont(new Font("Calibri Light", Font.BOLD, 20));
		btnNewButton_10.setBounds(860, 81, 180, 38);
		contentPane.add(btnNewButton_10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(173, 334, 867, 262);
		contentPane.add(scrollPane);

		table=new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
						"Patient ID","Patient Name","Contact No","Address","Date Of Birth","Gender","Any Allergy"
				}
				));
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Times New Roman", Font.BOLD, 18));
		textField_5.setBounds(527, 270, 120, 31);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Times New Roman", Font.BOLD, 20));
		textField_6.setBounds(588, 90, 45, 33);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		JButton btnNewButton_7 = new JButton("List Update");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				initComponant();
			}
		});
		btnNewButton_7.setFont(new Font("Times New Roman", Font.BOLD, 17));
		btnNewButton_7.setBounds(919, 276, 121, 37);
		contentPane.add(btnNewButton_7);
	}
}

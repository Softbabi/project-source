package login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.MatteBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.JTextField;

public class FeedBack extends JFrame {

	private JPanel contentPane;
	private JTextField t3;
	private JTextField t2;
	private JTextField t1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FeedBack frame = new FeedBack();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FeedBack() {
		setTitle("FeedBack");
		setIconImage(Toolkit.getDefaultToolkit().getImage(FeedBack.class.getResource("/Image/dr_logo.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1139, 672);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setForeground(new Color(64, 0, 64));
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(new Color(255, 165, 0));
		panel.setBounds(10, 10, 1098, 132);
		contentPane.add(panel);
		
		JLabel lblFeedBack = new JLabel("FeedBack");
		lblFeedBack.setHorizontalAlignment(SwingConstants.CENTER);
		lblFeedBack.setForeground(Color.GRAY);
		lblFeedBack.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 60));
		lblFeedBack.setBounds(404, 29, 286, 72);
		panel.add(lblFeedBack);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(255, 160, 122));
		panel_1.setBounds(10, 152, 204, 492);
		contentPane.add(panel_1);
		
		JButton btnNewButton_2 = new JButton("\r\nAppointment");
		btnNewButton_2.setForeground(new Color(0, 100, 0));
		btnNewButton_2.setFont(new Font("Tw Cen MT", Font.BOLD, 27));
		btnNewButton_2.setBounds(10, 35, 184, 105);
		panel_1.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("FeedBack");
		btnNewButton_3.setForeground(new Color(0, 100, 0));
		btnNewButton_3.setFont(new Font("Tw Cen MT", Font.BOLD, 34));
		btnNewButton_3.setBounds(10, 341, 184, 105);
		panel_1.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("ABOUT");
		btnNewButton_4.setForeground(new Color(0, 100, 0));
		btnNewButton_4.setFont(new Font("Tw Cen MT", Font.BOLD, 40));
		btnNewButton_4.setBounds(10, 187, 184, 116);
		panel_1.add(btnNewButton_4);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBorder(null);
		panel_2.setBackground(new Color(255, 250, 205));
		panel_2.setAlignmentX(1.0f);
		panel_2.setBounds(214, 133, 894, 492);
		contentPane.add(panel_2);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setIcon(new ImageIcon(FeedBack.class.getResource("/Image/back.png")));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_1.setBounds(734, 10, 150, 49);
		panel_2.add(btnNewButton_1);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 62, 884, 2);
		panel_2.add(separator);
		
		JLabel lblNewLabel_2 = new JLabel("FeedBack Form");
		lblNewLabel_2.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_2.setForeground(new Color(128, 0, 0));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_2.setBounds(322, 11, 359, 35);
		panel_2.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Name :");
		lblNewLabel_3.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_3.setBounds(23, 93, 112, 26);
		panel_2.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Contact :");
		lblNewLabel_4.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_4.setBounds(23, 143, 112, 29);
		panel_2.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Address :");
		lblNewLabel_5.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_5.setBounds(23, 194, 112, 29);
		panel_2.add(lblNewLabel_5);
		
		t3 = new JTextField();
		t3.setSelectionColor(new Color(255, 160, 122));
		t3.setForeground(Color.BLACK);
		t3.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t3.setDisabledTextColor(new Color(255, 160, 122));
		t3.setColumns(10);
		t3.setBorder(null);
		t3.setBackground(new Color(255, 192, 203));
		t3.setBounds(132, 195, 235, 30);
		panel_2.add(t3);
		
		t2 = new JTextField();
		t2.setSelectionColor(new Color(255, 160, 122));
		t2.setForeground(Color.BLACK);
		t2.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t2.setDisabledTextColor(new Color(255, 160, 122));
		t2.setColumns(10);
		t2.setBorder(null);
		t2.setBackground(new Color(255, 192, 203));
		t2.setBounds(132, 144, 235, 30);
		panel_2.add(t2);
		
		t1 = new JTextField();
		t1.setSelectionColor(new Color(255, 160, 122));
		t1.setForeground(Color.BLACK);
		t1.setFont(new Font("Tempus Sans ITC", Font.BOLD, 24));
		t1.setDisabledTextColor(new Color(255, 160, 122));
		t1.setColumns(10);
		t1.setBorder(null);
		t1.setBackground(new Color(255, 192, 203));
		t1.setBounds(132, 91, 235, 30);
		panel_2.add(t1);
		
		JLabel lblNewLabel_5_1 = new JLabel("Doctor Name :");
		lblNewLabel_5_1.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_5_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_5_1.setBounds(23, 244, 144, 29);
		panel_2.add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_5_2 = new JLabel("Address :");
		lblNewLabel_5_2.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_5_2.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_5_2.setBounds(23, 295, 112, 29);
		panel_2.add(lblNewLabel_5_2);
		
		JLabel lblNewLabel_5_3 = new JLabel("Address :");
		lblNewLabel_5_3.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_5_3.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_5_3.setBounds(23, 356, 112, 29);
		panel_2.add(lblNewLabel_5_3);
		
		JLabel lblNewLabel_5_4 = new JLabel("Address :");
		lblNewLabel_5_4.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_5_4.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_5_4.setBounds(23, 416, 112, 29);
		panel_2.add(lblNewLabel_5_4);
	}
}

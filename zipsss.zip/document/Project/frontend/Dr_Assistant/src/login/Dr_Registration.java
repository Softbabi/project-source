package login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Toolkit;
import java.awt.event.ActionListener;

import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Dr_Registration extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JPasswordField passwordField;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dr_Registration frame = new Dr_Registration();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Dr_Registration() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\HMS ICON\\rsz_hospital_information.png"));
		setTitle("Dr_Registration");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(50, 30, 1100, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel_10 = new JLabel("Contact No");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_10.setBounds(222, 459, 116, 29);
		contentPane.add(lblNewLabel_10);

		JLabel lblNewLabel = new JLabel("Doctor Registration");
		lblNewLabel.setForeground(new Color(255, 69, 0));
		lblNewLabel.setBounds(353, 72, 422, 56);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 40));
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_7 = new JLabel("Doctor Name");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_7.setBounds(222, 188, 135, 29);
		contentPane.add(lblNewLabel_7);

		JLabel lblNewLabel_3 = new JLabel("User Name");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3.setBounds(222, 293, 135, 39);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_5 = new JLabel("Qualification");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_5.setBounds(222, 242, 135, 29);
		contentPane.add(lblNewLabel_5);

		JLabel lblNewLabel_4 = new JLabel("Password");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_4.setBounds(222, 346, 116, 39);
		contentPane.add(lblNewLabel_4);

		JLabel lblNewLabel_9 = new JLabel("Email_ID");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_9.setBounds(222, 406, 116, 25);
		contentPane.add(lblNewLabel_9);

		JButton btnNewButton = new JButton("Save");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(textField.getText()==null )
					{
						JOptionPane.showMessageDialog(null,"Data Insert First","Status",JOptionPane.INFORMATION_MESSAGE);
					}
					else {
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","chetan123");
//						Statement st=con.createStatement();
						PreparedStatement pst=con.prepareStatement("Insert into Doctor values(?,?,?,?,?,?,DocID)");
						pst.setString(1,textField.getText());
						pst.setString(2,textField_1.getText());
						pst.setString(3,textField_2.getText());
						pst.setString(4,passwordField.getText());
						pst.setString(5,textField_4.getText());
						pst.setString(6,textField_3.getText());

						pst.executeUpdate();

						//pst.clearParameters();
						//String sql="Insert into Doctor values('Chetan','MBBS','chetan','123','9876543210','admin@gmail.com')";
						//st.executeUpdate(sql);
						JOptionPane.showMessageDialog(null,"Data Inserted Succesfully","Status",JOptionPane.INFORMATION_MESSAGE);
						//System.out.println("Data Inserted");

						textField.setText("");
						textField_1.setText("");
						textField_2.setText("");
						textField_3.setText("");
						textField_4.setText("");
						passwordField.setText("");
					}
				}
				catch(Exception ex) {
					JOptionPane.showMessageDialog(null,ex,"Status",JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 30));
		btnNewButton.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\save-icon--1.png"));
		btnNewButton.setBounds(415, 514, 128, 50);
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("Back To Login");
		btnNewButton_1.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				
				try {
					Login obj = new Login();
					obj.setVisible(true);
					dispose();
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\back.png"));
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_1.setBounds(564, 524, 211, 39);
		contentPane.add(btnNewButton_1);

		textField = new JTextField();
		textField.setBounds(415, 188, 360, 28);
		contentPane.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(415, 242, 360, 28);
		contentPane.add(textField_1);

		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(415, 307, 360, 28);
		contentPane.add(textField_2);

		textField_3 = new JTextField();
		textField_3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Validation obj=new Validation();
				
			}
		});
		textField_3.setColumns(10);
		textField_3.setBounds(415, 413, 360, 28);
		contentPane.add(textField_3);

		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(415, 459, 360, 28);
		contentPane.add(textField_4);

		passwordField = new JPasswordField();
		passwordField.setBounds(415, 360, 360, 28);
		contentPane.add(passwordField);

		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login obj;
				try {
					obj = new Login();
					obj.setVisible(true);
					dispose();
				} catch (Exception e1) {
					e1.printStackTrace();
				} 
			}
		});
		btnNewButton_2.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\back.png"));
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_2.setBounds(926, 10, 135, 56);
		contentPane.add(btnNewButton_2);

		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(164, 140, 780, 500);
		lblNewLabel_2.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\add new patient background.jpg"));
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(0, 0, 1100, 800);
		lblNewLabel_1.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\BGGG.png"));
		contentPane.add(lblNewLabel_1);
	}
}

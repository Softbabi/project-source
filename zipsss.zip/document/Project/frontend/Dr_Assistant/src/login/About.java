package login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.border.MatteBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class About extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					About frame = new About();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public About() {
		setTitle("About");
		setIconImage(Toolkit.getDefaultToolkit().getImage(About.class.getResource("/Image/dr_logo.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1113, 660);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBorder(null);
		panel_2.setBackground(new Color(255, 250, 205));
		panel_2.setAlignmentX(1.0f);
		panel_2.setBounds(204, 142, 894, 492);
		contentPane.add(panel_2);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setIcon(new ImageIcon(About.class.getResource("/Image/back.png")));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient obj=new Patient();
				obj.setVisible(true);;
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_1.setBounds(734, 10, 150, 49);
		panel_2.add(btnNewButton_1);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 62, 884, 2);
		panel_2.add(separator);
		
		JLabel lblNewLabel_2 = new JLabel("Dr_Assistant");
		lblNewLabel_2.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_2.setForeground(new Color(128, 0, 0));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_2.setBounds(322, 11, 359, 35);
		panel_2.add(lblNewLabel_2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(255, 160, 122));
		panel_1.setBounds(0, 142, 204, 492);
		contentPane.add(panel_1);
		
		JButton btnNewButton_2 = new JButton("\r\nAppointment");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Appointment obj=new Appointment();
				obj.setVisible(true);;
				dispose();
			}
		});
		btnNewButton_2.setForeground(new Color(0, 100, 0));
		btnNewButton_2.setFont(new Font("Tw Cen MT", Font.BOLD, 27));
		btnNewButton_2.setBounds(10, 35, 184, 105);
		panel_1.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("FeedBack");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FeedBack obj=new FeedBack();
				obj.setVisible(true);;
				dispose();
			}
		});
		btnNewButton_3.setForeground(new Color(0, 100, 0));
		btnNewButton_3.setFont(new Font("Tw Cen MT", Font.BOLD, 34));
		btnNewButton_3.setBounds(10, 341, 184, 105);
		panel_1.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("ABOUT");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"You already in About page");
			}
		});
		btnNewButton_4.setForeground(new Color(0, 100, 0));
		btnNewButton_4.setFont(new Font("Tw Cen MT", Font.BOLD, 40));
		btnNewButton_4.setBounds(10, 187, 184, 116);
		panel_1.add(btnNewButton_4);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setForeground(new Color(64, 0, 64));
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(new Color(255, 165, 0));
		panel.setBounds(0, 0, 1098, 132);
		contentPane.add(panel);
		
		JLabel lblAbout = new JLabel("About ");
		lblAbout.setHorizontalAlignment(SwingConstants.CENTER);
		lblAbout.setForeground(Color.GRAY);
		lblAbout.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 60));
		lblAbout.setBounds(404, 29, 286, 72);
		panel.add(lblAbout);
	}
}

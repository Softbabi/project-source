package login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Toolkit;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JScrollBar;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Patient_registration extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	Patient_registration frame;
	private JTextField textField_4;
	Connection con;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Patient_registration frame = new Patient_registration();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public Patient_registration() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","chetan123");
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\HMS ICON\\add new patient.png"));
		setTitle("Patient_Registration");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 30, 1100, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Patient Registration");
		lblNewLabel.setForeground(new Color(255, 69, 0));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 40));
		lblNewLabel.setBounds(363, 51, 426, 63);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_1.setBounds(286, 166, 185, 37);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
						
		});
		textField.setBounds(506, 178, 283, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Patient obj=new Patient();
			obj.setVisible(true);
			dispose();
			}
		});
		btnNewButton_2.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\back.png"));
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_2.setBounds(930, 61, 135, 56);
		contentPane.add(btnNewButton_2);
		
		ButtonGroup group=new ButtonGroup();
		
		JPanel panel = new JPanel();
		panel.setBounds(211, 141, 641, 459);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JScrollBar scrollBar = new JScrollBar();
		scrollBar.setValue(1);
		scrollBar.setBounds(602, 20, 29, 429);
		panel.add(scrollBar);
		
		textField_4 = new JTextField();
		textField_4.setBounds(294, 345, 283, 26);
		panel.add(textField_4);
		textField_4.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent ke) {
				String value = textField_1.getText();
	            int l = value.length();
	            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9') {
	            	textField_1.setEditable(true);
	               
	            } else {
	            	textField_1.setEditable(false);
	                textField_1.setText("");
	            	JOptionPane.showMessageDialog(null,"Enter Only Number" );
	            }
			}
		});
		textField_1.setBounds(294, 90, 283, 26);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(294, 156, 283, 26);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Calibri Light", Font.BOLD, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
		comboBox.setToolTipText("");
		comboBox.setBounds(294, 283, 283, 26);
		panel.add(comboBox);
		
		JButton btnNewButton = new JButton("Save");
		btnNewButton.setBounds(372, 401, 118, 37);
		panel.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					PreparedStatement pst=con.prepareStatement("Insert into patient values(pID,?,?,?,?,?,?)");
					pst.setString(1, textField.getText());
					pst.setInt(2, Integer.parseInt(textField_1.getText()));
					pst.setString(3, textField_2.getText());
					pst.setString(4, textField_3.getText());
					String item=(String) comboBox.getSelectedItem();
					pst.setString(5, item);
					pst.setString(6, textField_4.getText());
					pst.executeUpdate();
					pst.clearParameters();
					JOptionPane.showMessageDialog(null,"Data Inserted Succesfully","Status",JOptionPane.INFORMATION_MESSAGE);
//					
//					textField.setText("");
//					textField_1.setText("");
//					textField_2.setText("");
//					textField_3.setText("");
//					textField_4.setText("");
					dispose();
					
					
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null,e1,"Status",JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		btnNewButton.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\save-icon--1.png"));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 24));
				
		JLabel lblNewLabel_2 = new JLabel("Date Of Birth");
		lblNewLabel_2.setBounds(70, 206, 173, 37);
		panel.add(lblNewLabel_2);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 25));
		
		JLabel lblNewLabel_3 = new JLabel("Contact No\r\n");
		lblNewLabel_3.setBounds(70, 78, 173, 37);
		panel.add(lblNewLabel_3);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 25));
		
		JLabel lblNewLabel_5 = new JLabel("Address");
		lblNewLabel_5.setBounds(70, 137, 149, 51);
		panel.add(lblNewLabel_5);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 25));
		
		JLabel lblNewLabel_4 = new JLabel("Gender");
		lblNewLabel_4.setBounds(70, 283, 135, 26);
		panel.add(lblNewLabel_4);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 25));
		
		textField_3 = new JTextField();
		textField_3.setBounds(294, 218, 283, 26);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Any Other Allergy");
		lblNewLabel_6.setBounds(70, 335, 178, 37);
		panel.add(lblNewLabel_6);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		
		JLabel lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\add new patient background.jpg"));
		lblNewLabel_8.setBounds(140, 124, 780, 500);
		contentPane.add(lblNewLabel_8);
		
		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\BGGG.png"));
		lblNewLabel_7.setBounds(0, 0, 1100, 800);
		contentPane.add(lblNewLabel_7);
	}
}

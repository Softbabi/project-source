package login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.*;

import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import javax.swing.JRadioButton;

public class Login extends JFrame {

	private JPanel contentPane;
	private JPasswordField passwordField;
	private JTextField textField,textField1;
	Connection con;
	Patient_Home obj=new Patient_Home();
	public Login() throws SQLException,ClassNotFoundException{
		setResizable(false);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	   
			 Class.forName("com.mysql.cj.jdbc.Driver");
			 final Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","chetan123");
	        
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Admin\\Downloads\\L_logo.jpg"));
		setTitle("Login");
		setBounds(0, 0, 1370, 770);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblNewLabel.setBounds(616, 344, 116, 40);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password\r\n");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblNewLabel_1.setBounds(616, 394, 111, 31);
		contentPane.add(lblNewLabel_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(732, 394, 231, 29);
		contentPane.add(passwordField);
		
		textField = new JTextField();
		textField.setBounds(732, 353, 231, 29);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Login");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.ITALIC, 42));
		lblNewLabel_2.setBounds(691, 270, 128, 51);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\login.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					PreparedStatement pst=con.prepareStatement("select * from Doctor where DocUserName=? AND DocPassword=?");

					pst.setString(1,textField.getText());
					pst.setString(2,passwordField.getText());
					ResultSet rs=pst.executeQuery(); 
					if(rs.next())
					{  
						String name=rs.getString(1);
						obj.name(name);
						JOptionPane.showMessageDialog(null,"Login Succesfull","Status",JOptionPane.INFORMATION_MESSAGE);
						Home obj=new Home();
						obj.setVisible(true);
						
						dispose();
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Undefine Detail","Status",JOptionPane.INFORMATION_MESSAGE);
						textField.setText("");
						passwordField.setText("");
					}
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null,ex,"Status",JOptionPane.INFORMATION_MESSAGE);
				}       		     
			}	
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 25));
		btnNewButton.setBounds(740, 496, 128, 51);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("New Registration");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Dr_Registration obj=new Dr_Registration();
				obj.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_1.setBounds(793, 179, 231, 29);
		contentPane.add(btnNewButton_1);
		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Dr_Assistant obj=new Dr_Assistant();
				obj.setVisible(true);;
				dispose();
			}
		});
		
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 22));
		btnNewButton_2.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\back.png"));
		btnNewButton_2.setBounds(1122, 40, 155, 51);
		contentPane.add(btnNewButton_2);
		
		final JRadioButton rdbtnNewRadioButton = new JRadioButton("Show Password");
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(rdbtnNewRadioButton.isSelected())
				{
					  passwordField.setEchoChar((char)0); 
				}
				else {
					passwordField.setEchoChar('*'); 
				}
			}
		});
		rdbtnNewRadioButton.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		rdbtnNewRadioButton.setBounds(752, 443, 166, 31);
		contentPane.add(rdbtnNewRadioButton);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\login Background final.PNG"));
		lblNewLabel_3.setBounds(0, 0, 1366, 768);
		contentPane.add(lblNewLabel_3);
	}
	public static void main(String[] args) {
		try{
			Login obj=new Login();
			obj.setVisible(true);
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,e,"Status",JOptionPane.INFORMATION_MESSAGE);
		}
	}
}
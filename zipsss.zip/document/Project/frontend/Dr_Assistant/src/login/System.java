package login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.border.EtchedBorder;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class System extends JFrame {
	private JTextField textField;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	private JTextField t4;
	private JTextField t5;
	private JTextField t6;
	Connection con;
	PreparedStatement pst;
	

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					System frame = new System();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public System() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","chetan123");
		} catch (Exception e1) {
			JOptionPane.showMessageDialog(null,e1);
		}
		setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\clgJava\\Dr_Assistance\\src\\Image\\dr_logo.png"));
		setTitle("Setting");
		setBounds(new Rectangle(100, 80, 1100, 700));
		getContentPane().setBackground(new Color(240, 230, 140));
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(25, 25, 112), new Color(95, 158, 160)));
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(10, 99, 154, 512);
		getContentPane().add(panel);
		
		JButton btnNewButton_2 = new JButton("Home");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setForeground(new Color(128, 0, 0));
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_2.setBounds(10, 10, 134, 90);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Prescription");
		btnNewButton_3.setForeground(new Color(128, 0, 0));
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 19));
		btnNewButton_3.setBounds(10, 110, 134, 90);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Patient");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient obj=new Patient();
				obj.setVisible(true);
				dispose();
			}
		});
		btnNewButton_4.setForeground(new Color(128, 0, 0));
		btnNewButton_4.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_4.setBounds(10, 207, 134, 90);
		panel.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Appoitment");
		btnNewButton_5.setForeground(new Color(128, 0, 0));
		btnNewButton_5.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_5.setBounds(10, 307, 134, 90);
		panel.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("System");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"You Already System Page","Status",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnNewButton_6.setForeground(new Color(128, 0, 0));
		btnNewButton_6.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_6.setBounds(10, 407, 134, 90);
		panel.add(btnNewButton_6);
		
		JLabel lblNewLabel_9 = new JLabel("");
		lblNewLabel_9.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\icon\\settings.png"));
		lblNewLabel_9.setForeground(new Color(255, 69, 0));
		lblNewLabel_9.setFont(new Font("Calibri Light", Font.BOLD, 25));
		lblNewLabel_9.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_9.setBounds(10, 10, 144, 70);
		getContentPane().add(lblNewLabel_9);
		
		JButton btnNewButton_1 = new JButton("Logout");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Login obj=new Login();
					obj.setVisible(true);
					dispose();
					}catch(Exception ex) {
						JOptionPane.showMessageDialog(null,ex,"Status",JOptionPane.INFORMATION_MESSAGE);
					}
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("D:\\clgJava\\Dr_Assistance\\src\\Image\\exit.png"));
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnNewButton_1.setBounds(866, 0, 174, 60);
		getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Exit\r\n");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a=JOptionPane.showConfirmDialog(null,"Do you Want to close the application","select",JOptionPane.YES_NO_OPTION);
				   if (a==0)
				   {
				      dispose();
				   }
			}
		});
		btnNewButton.setIcon(new ImageIcon("E:\\Image\\Close.png"));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnNewButton.setBounds(919, 70, 121, 45);
		getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("DR ASSISTANT");
		lblNewLabel.setForeground(new Color(128, 0, 0));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 60));
		lblNewLabel.setBounds(285, 0, 419, 70);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setIcon(new ImageIcon("E:\\Image\\icon\\890961816.png"));
		lblNewLabel_6.setBounds(164, 0, 673, 86);
		getContentPane().add(lblNewLabel_6);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.GRAY);
		separator.setBounds(164, 142, 874, 12);
		getContentPane().add(separator);
		
		JLabel lblNewLabel_1 = new JLabel("System Access\r\n");
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setFont(new Font("Calibri Light", Font.BOLD | Font.ITALIC, 35));
		lblNewLabel_1.setBounds(406, 103, 229, 39);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Update Your Profile");
		lblNewLabel_2.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel_2.setBounds(455, 164, 312, 39);
		getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Name :");
		lblNewLabel_3.setFont(new Font("Yu Gothic", Font.BOLD, 20));
		lblNewLabel_3.setBounds(381, 241, 142, 35);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Qualification :");
		lblNewLabel_4.setFont(new Font("Yu Gothic", Font.BOLD, 20));
		lblNewLabel_4.setBounds(381, 286, 142, 37);
		getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("User Name : ");
		lblNewLabel_5.setFont(new Font("Yu Gothic", Font.BOLD, 20));
		lblNewLabel_5.setBounds(381, 333, 142, 33);
		getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_7 = new JLabel("Contact :");
		lblNewLabel_7.setFont(new Font("Yu Gothic", Font.BOLD, 20));
		lblNewLabel_7.setBounds(381, 387, 142, 38);
		getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Password :");
		lblNewLabel_8.setFont(new Font("Yu Gothic", Font.BOLD, 20));
		lblNewLabel_8.setBounds(381, 445, 145, 37);
		getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_10 = new JLabel("Email :");
		lblNewLabel_10.setFont(new Font("Yu Gothic", Font.BOLD, 20));
		lblNewLabel_10.setBounds(381, 496, 97, 35);
		getContentPane().add(lblNewLabel_10);
		
		textField = new JTextField();
		textField.setFont(new Font("Tempus Sans ITC", Font.ITALIC, 20));
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				try {
					PreparedStatement pst=con.prepareStatement("select * from Doctor where Docid=?");
					pst.setString(1, textField.getText());
					ResultSet rs=pst.executeQuery();
					if(rs.next()) {
						t1.setText(rs.getString(1));
						t2.setText(rs.getString(2));
						t3.setText(rs.getString(3));
						t4.setText(rs.getString(5));
						t5.setText(rs.getString(4));
						t6.setText(rs.getString(6));
					}
					else {
						t1.setText("");
						t2.setText("");
						t3.setText("");
						t4.setText("");
						t5.setText("");
						t6.setText("");
					}
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null,e1);
				}		
			}
		});
		textField.setBackground(new Color(240, 230, 140));
		textField.setSelectedTextColor(new Color(255, 255, 255));
		textField.setBounds(268, 164, 42, 39);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_11 = new JLabel("Enter ID : ");
		lblNewLabel_11.setFont(new Font("Tw Cen MT", Font.BOLD, 22));
		lblNewLabel_11.setBounds(174, 164, 97, 39);
		getContentPane().add(lblNewLabel_11);
		
		t1 = new JTextField();
		t1.setFont(new Font("Tempus Sans ITC", Font.ITALIC, 20));
		t1.setBorder(null);
		t1.setBackground(new Color(250, 250, 210));
		t1.setBounds(522, 245, 301, 24);
		getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		t2.setFont(new Font("Tempus Sans ITC", Font.ITALIC, 20));
		t2.setBorder(null);
		t2.setBackground(new Color(250, 250, 210));
		t2.setColumns(10);
		t2.setBounds(522, 286, 301, 24);
		getContentPane().add(t2);
		
		t3 = new JTextField();
		t3.setFont(new Font("Tempus Sans ITC", Font.ITALIC, 20));
		t3.setBorder(null);
		t3.setBackground(new Color(250, 250, 210));
		t3.setColumns(10);
		t3.setBounds(522, 336, 301, 24);
		getContentPane().add(t3);
		
		t4 = new JTextField();
		t4.setFont(new Font("Tempus Sans ITC", Font.ITALIC, 20));
		t4.setBorder(null);
		t4.setBackground(new Color(250, 250, 210));
		t4.setColumns(10);
		t4.setBounds(522, 393, 301, 24);
		getContentPane().add(t4);
		
		t5 = new JTextField();
		t5.setFont(new Font("Tempus Sans ITC", Font.ITALIC, 20));
		t5.setBorder(null);
		t5.setBackground(new Color(250, 250, 210));
		t5.setColumns(10);
		t5.setBounds(522, 445, 301, 24);
		getContentPane().add(t5);
		
		t6 = new JTextField();
		t6.setFont(new Font("Tempus Sans ITC", Font.ITALIC, 20));
		t6.setBorder(null);
		t6.setBackground(new Color(250, 250, 210));
		t6.setColumns(10);
		t6.setBounds(522, 492, 301, 24);
		getContentPane().add(t6);
		
		JButton btnNewButton_7 = new JButton("Update");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					pst=con.prepareStatement("update Doctor set DocName=?,DocQualy=?,DocUserName=?,DocContact=?,DocPassword=?,DocEmail=? where Docid=?");
				
					pst.setString(1, t1.getText());
					pst.setString(2, t2.getText());
					pst.setString(3, t3.getText());
					pst.setString(4, t4.getText());
					pst.setString(5, t5.getText());
					pst.setString(6, t6.getText());
					pst.setString(7, textField.getText());
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "Data Updated");
					textField.setText("");
					t1.setText("");
					t2.setText("");
					t3.setText("");
					t4.setText("");
					t5.setText("");
					t6.setText("");
				} catch (SQLException e1) {
					JOptionPane.showMessageDialog(null, e1);
				}	
			}
		});
		btnNewButton_7.setBackground(new Color(127, 255, 0));
		btnNewButton_7.setFont(new Font("Segoe UI Symbol", Font.BOLD, 30));
		btnNewButton_7.setBorder(null);
		btnNewButton_7.setBounds(571, 546, 121, 45);
		getContentPane().add(btnNewButton_7);
		
		JLabel lblNewLabel_12 = new JLabel("Will need to login");
		lblNewLabel_12.setForeground(new Color(153, 50, 204));
		lblNewLabel_12.setFont(new Font("Garamond", Font.BOLD, 17));
		lblNewLabel_12.setBounds(845, 334, 129, 25);
		getContentPane().add(lblNewLabel_12);
		
		JLabel lblNewLabel_13 = new JLabel("will print in prescription");
		lblNewLabel_13.setForeground(new Color(153, 50, 204));
		lblNewLabel_13.setFont(new Font("Garamond", Font.BOLD, 17));
		lblNewLabel_13.setBounds(845, 246, 180, 19);
		getContentPane().add(lblNewLabel_13);
		
	}
}

#include<iostream>
using namespace std;
void traverse(int array[],int n)
{
     cout<<"array";
   int i;
   for(i=0;i<=n;i++)
   {
        cout<<array[i]<<"";             
     }
      }
void main()
{
  cout<<"array:"<<endl;  
  int arr[]={64,87,65,15,54};
  int n=sizeof(array);
  traverse();
     }

def dfs(graph , start,goal):
visited []
stack []
visited.append(start)
stack.append(start)
print("the path traversed is ")
while stack:
    

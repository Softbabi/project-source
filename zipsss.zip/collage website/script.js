This website does not use JavaScript or just adds files

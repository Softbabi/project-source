# Interior Design

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/qBLELBV](https://codepen.io/yudizsolutions/pen/qBLELBV).

Using GSAP animation, we are creating an interior studio one-page design in HTML, CSS, and Bootstrap. We're utilizing a basic GSAP animation.


We took reference from our dribble shot: 
https://dribbble.com/shots/18253154-Interior-Design

Made by Radhika Bhadeliya from Yudiz
Friends, I have not used JavaScript in this project, I have only created this file so that you do not face any problem.
